<?php
echo "PHP Works!";
?>