<?php
// 最小限のPHPテスト
echo "<h1>PHP動作テスト</h1>";
echo "<p>PHP Version: " . PHP_VERSION . "</p>";
echo "<p>現在時刻: " . date('Y-m-d H:i:s') . "</p>";
echo "<p>このページが表示されれば、基本的なPHPは動作しています。</p>";
echo "<p><a href='emergency-check.php'>詳細診断に戻る</a></p>";
?>