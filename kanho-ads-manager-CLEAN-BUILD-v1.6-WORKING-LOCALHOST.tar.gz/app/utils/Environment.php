<?php

class Environment 
{
    private static $variables = [];
    private static $loaded = false;

    public static function load($path = null) 
    {
        if (self::$loaded) {
            return;
        }

        // より確実な.envファイルの検索
        if ($path === null) {
            // 複数のパターンを試す
            $possible_paths = [
                __DIR__ . '/../../.env',           // 通常のパス
                dirname(dirname(__DIR__)) . '/.env', // より安全なパス  
                $_SERVER['DOCUMENT_ROOT'] . '/../.env',  // Document rootの上
                getcwd() . '/.env',                // 現在のディレクトリ
                dirname($_SERVER['SCRIPT_FILENAME']) . '/.env', // 実行ファイルと同じディレクトリ
            ];
            
            $path = null;
            foreach ($possible_paths as $test_path) {
                if (file_exists($test_path)) {
                    $path = $test_path;
                    break;
                }
            }
            
            // それでも見つからない場合は、実行時に詳細情報を表示
            if ($path === null) {
                $debug_info = "Environment file not found. Searched paths:\n";
                foreach ($possible_paths as $i => $test_path) {
                    $debug_info .= ($i + 1) . ". " . $test_path . " - " . (file_exists($test_path) ? "EXISTS" : "NOT FOUND") . "\n";
                }
                $debug_info .= "\nCurrent working directory: " . getcwd() . "\n";
                $debug_info .= "Script filename: " . $_SERVER['SCRIPT_FILENAME'] . "\n";
                $debug_info .= "__DIR__: " . __DIR__ . "\n";
                $debug_info .= "DOCUMENT_ROOT: " . ($_SERVER['DOCUMENT_ROOT'] ?? 'NOT SET') . "\n";
                
                throw new Exception($debug_info);
            }
        }

        if (!file_exists($path)) {
            throw new Exception("Environment file not found: " . $path);
        }

        $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        
        foreach ($lines as $line) {
            $line = trim($line);
            
            // Skip comments and empty lines
            if (empty($line) || $line[0] === '#') {
                continue;
            }
            
            // Parse key=value
            if (strpos($line, '=') !== false) {
                list($key, $value) = explode('=', $line, 2);
                $key = trim($key);
                $value = trim($value);
                
                // Remove quotes if present
                if ((substr($value, 0, 1) === '"' && substr($value, -1) === '"') ||
                    (substr($value, 0, 1) === "'" && substr($value, -1) === "'")) {
                    $value = substr($value, 1, -1);
                }
                
                self::$variables[$key] = $value;
            }
        }
        
        self::$loaded = true;
    }

    public static function get($key, $default = null) 
    {
        if (!self::$loaded) {
            self::load();
        }
        
        return isset(self::$variables[$key]) ? self::$variables[$key] : $default;
    }

    public static function isDevelopment() 
    {
        return self::get('APP_ENV', 'production') === 'development';
    }

    public static function isDebug() 
    {
        return self::get('APP_DEBUG', 'false') === 'true';
    }
    
    // デバッグ用メソッド
    public static function getLoadedPath()
    {
        return self::$loaded;
    }
    
    public static function getAllVariables()
    {
        return self::$variables;
    }
}