<?php
echo "PHP Works!";
echo "<br>PHP Version: " . PHP_VERSION;
echo "<br>Time: " . date('Y-m-d H:i:s');
?>