<?php
// 最も基本的なPHP動作確認
echo "Step 1: Basic PHP Test<br>";
echo "PHP Version: " . PHP_VERSION . "<br>";
echo "Current Directory: " . __DIR__ . "<br>";
echo "Date: " . date('Y-m-d H:i:s') . "<br>";
?>